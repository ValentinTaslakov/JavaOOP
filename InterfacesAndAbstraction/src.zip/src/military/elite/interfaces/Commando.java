package military.elite.interfaces;

import java.util.Collection;

public interface Commando {
    Collection<Mission> getMissions();
}
