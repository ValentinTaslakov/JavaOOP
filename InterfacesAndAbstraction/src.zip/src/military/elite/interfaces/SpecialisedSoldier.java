package military.elite.interfaces;

public interface SpecialisedSoldier extends Soldier {
    String getCorps();
}
