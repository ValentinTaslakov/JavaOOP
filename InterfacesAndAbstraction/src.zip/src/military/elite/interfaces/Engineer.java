package military.elite.interfaces;

import java.util.Collection;

public interface Engineer {
    Collection<Repair> getRepairs();
}
