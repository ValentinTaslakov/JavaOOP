package military.elite.interfaces;

public interface Repair {
    String getPartName();

    int getHours();
}
