package military.elite.interfaces;

public interface Private extends Soldier {
    double getSalary();
}
