package military.elite.interfaces;

public interface Spy {
    String getCodeNumber();
}
