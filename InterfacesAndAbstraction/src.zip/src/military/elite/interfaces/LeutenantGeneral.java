package military.elite.interfaces;

import java.util.Collection;

public interface LeutenantGeneral {

    Collection<Private> getPrivates();

}
