package military.elite.interfaces;

public interface Mission {
    String getCodeName();
    String getState();
    void completeMission();
}
